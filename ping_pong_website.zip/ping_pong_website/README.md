# Ping Pong Website

A basic two-player-style Ping Pong game where you control the left paddle and play against a simple computer opponent.

## Run locally

Open `index.html` in a modern web browser.

## Controls

- W / S
- Up / Down arrow keys
- On mobile: drag on the game area

First to 5 points wins.

## Files

- `index.html` — webpage structure
- `style.css` — layout and styling
- `script.js` — game logic and controls
