const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const playerScoreEl = document.getElementById("playerScore");
const computerScoreEl = document.getElementById("computerScore");
const restartBtn = document.getElementById("restart");

const WIDTH = canvas.width;
const HEIGHT = canvas.height;
const PADDLE_WIDTH = 14;
const PADDLE_HEIGHT = 100;
const WINNING_SCORE = 5;

const player = {
  x: 26,
  y: HEIGHT / 2 - PADDLE_HEIGHT / 2,
  speed: 8
};

const computer = {
  x: WIDTH - 40,
  y: HEIGHT / 2 - PADDLE_HEIGHT / 2,
  speed: 5
};

const ball = {
  x: WIDTH / 2,
  y: HEIGHT / 2,
  radius: 9,
  vx: 6,
  vy: 3
};

let playerScore = 0;
let computerScore = 0;
let gameOver = false;
let keys = {};
let lastTime = 0;

function updateScore() {
  playerScoreEl.textContent = playerScore;
  computerScoreEl.textContent = computerScore;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function resetBall(direction = Math.random() < 0.5 ? -1 : 1) {
  ball.x = WIDTH / 2;
  ball.y = HEIGHT / 2;

  const speed = 6;
  ball.vx = direction * speed;
  ball.vy = (Math.random() * 2 - 1) * 4;
}

function resetGame() {
  playerScore = 0;
  computerScore = 0;
  gameOver = false;

  player.y = HEIGHT / 2 - PADDLE_HEIGHT / 2;
  computer.y = HEIGHT / 2 - PADDLE_HEIGHT / 2;

  resetBall();
  updateScore();
}

function update(delta) {
  if (gameOver) return;

  const scale = delta / 16.67;

  if (keys["w"] || keys["arrowup"]) {
    player.y -= player.speed * scale;
  }
  if (keys["s"] || keys["arrowdown"]) {
    player.y += player.speed * scale;
  }

  player.y = clamp(player.y, 0, HEIGHT - PADDLE_HEIGHT);

  // Simple computer opponent.
  const targetY = ball.y - PADDLE_HEIGHT / 2;
  if (computer.y < targetY) {
    computer.y += computer.speed * scale;
  } else if (computer.y > targetY) {
    computer.y -= computer.speed * scale;
  }
  computer.y = clamp(computer.y, 0, HEIGHT - PADDLE_HEIGHT);

  ball.x += ball.vx * scale;
  ball.y += ball.vy * scale;

  // Top and bottom walls.
  if (ball.y - ball.radius <= 0 || ball.y + ball.radius >= HEIGHT) {
    ball.vy *= -1;
    ball.y = clamp(ball.y, ball.radius, HEIGHT - ball.radius);
  }

  // Player collision.
  if (
    ball.vx < 0 &&
    ball.x - ball.radius <= player.x + PADDLE_WIDTH &&
    ball.x + ball.radius >= player.x &&
    ball.y >= player.y &&
    ball.y <= player.y + PADDLE_HEIGHT
  ) {
    const relativeHit = (ball.y - (player.y + PADDLE_HEIGHT / 2)) / (PADDLE_HEIGHT / 2);
    ball.vx = Math.abs(ball.vx) + 0.25;
    ball.vy = relativeHit * 6;
    ball.x = player.x + PADDLE_WIDTH + ball.radius;
  }

  // Computer collision.
  if (
    ball.vx > 0 &&
    ball.x + ball.radius >= computer.x &&
    ball.x - ball.radius <= computer.x + PADDLE_WIDTH &&
    ball.y >= computer.y &&
    ball.y <= computer.y + PADDLE_HEIGHT
  ) {
    const relativeHit = (ball.y - (computer.y + PADDLE_HEIGHT / 2)) / (PADDLE_HEIGHT / 2);
    ball.vx = -Math.abs(ball.vx) - 0.25;
    ball.vy = relativeHit * 6;
    ball.x = computer.x - ball.radius;
  }

  // Scoring.
  if (ball.x < -30) {
    computerScore++;
    updateScore();

    if (computerScore >= WINNING_SCORE) {
      gameOver = true;
    } else {
      resetBall(1);
    }
  }

  if (ball.x > WIDTH + 30) {
    playerScore++;
    updateScore();

    if (playerScore >= WINNING_SCORE) {
      gameOver = true;
    } else {
      resetBall(-1);
    }
  }
}

function draw() {
  ctx.clearRect(0, 0, WIDTH, HEIGHT);

  // Center line.
  ctx.strokeStyle = "#444";
  ctx.lineWidth = 3;
  ctx.setLineDash([12, 14]);
  ctx.beginPath();
  ctx.moveTo(WIDTH / 2, 0);
  ctx.lineTo(WIDTH / 2, HEIGHT);
  ctx.stroke();
  ctx.setLineDash([]);

  // Paddles.
  ctx.fillStyle = "#fff";
  ctx.fillRect(player.x, player.y, PADDLE_WIDTH, PADDLE_HEIGHT);
  ctx.fillRect(computer.x, computer.y, PADDLE_WIDTH, PADDLE_HEIGHT);

  // Ball.
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fill();

  if (gameOver) {
    ctx.fillStyle = "rgba(0, 0, 0, 0.76)";
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    ctx.fillStyle = "#fff";
    ctx.textAlign = "center";
    ctx.font = "700 48px Arial";
    ctx.fillText(
      playerScore > computerScore ? "YOU WIN!" : "CPU WINS!",
      WIDTH / 2,
      HEIGHT / 2 - 10
    );

    ctx.font = "24px Arial";
    ctx.fillText("Press Restart to play again", WIDTH / 2, HEIGHT / 2 + 38);
  }
}

function gameLoop(timestamp) {
  const delta = Math.min(timestamp - lastTime || 16.67, 34);
  lastTime = timestamp;

  update(delta);
  draw();

  requestAnimationFrame(gameLoop);
}

document.addEventListener("keydown", (event) => {
  const key = event.key.toLowerCase();
  keys[key] = true;

  if (["arrowup", "arrowdown", " "].includes(key)) {
    event.preventDefault();
  }
});

document.addEventListener("keyup", (event) => {
  keys[event.key.toLowerCase()] = false;
});

// Mobile and mouse drag controls.
function movePaddleFromPointer(clientY) {
  const rect = canvas.getBoundingClientRect();
  const canvasY = (clientY - rect.top) * (HEIGHT / rect.height);
  player.y = clamp(canvasY - PADDLE_HEIGHT / 2, 0, HEIGHT - PADDLE_HEIGHT);
}

canvas.addEventListener("touchstart", (event) => {
  event.preventDefault();
  movePaddleFromPointer(event.touches[0].clientY);
}, { passive: false });

canvas.addEventListener("touchmove", (event) => {
  event.preventDefault();
  movePaddleFromPointer(event.touches[0].clientY);
}, { passive: false });

canvas.addEventListener("mousedown", (event) => {
  movePaddleFromPointer(event.clientY);
});

canvas.addEventListener("mousemove", (event) => {
  if (event.buttons) {
    movePaddleFromPointer(event.clientY);
  }
});

restartBtn.addEventListener("click", resetGame);

resetGame();
requestAnimationFrame(gameLoop);
